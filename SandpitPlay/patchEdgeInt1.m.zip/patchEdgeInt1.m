% Provides the interpolation across space for 1D patches of
% simulations of a smooth lattice system such as PDE
% discretisations.
% AJR & JB, Sep 2018 -- Apr 2019

function u=patchEdgeInt1(u)
global patches


[nSubP,nPatch] = size(patches.x);
nVars = round(numel(u)/numel(patches.x));
if numel(u)~=nSubP*nPatch*nVars
  nSubP=nSubP, nPatch=nPatch, nVars=nVars, sizeu=size(u)
  end
u = reshape(u,nSubP,nPatch,nVars);

dx = patches.x(3,1)-patches.x(2,1);
DX = patches.x(2,2)-patches.x(2,1);

r = dx*(nSubP-2)/DX;

j = 1:nPatch; jp = mod(j,nPatch)+1; jm = mod(j-2,nPatch)+1;

% spectral interpolation
%{
\end{matlab}
As the macroscale fields are \(N\)-periodic, the macroscale
Fourier transform writes the next-to-edge-patch values as
\(U_j = \sum_{k}C_ke^{ik2\pi j/N}\). Then the edge-patch
values \(U_{j\pm r} =\sum_{k}C_ke^{ik2\pi/N(j\pm r)}
=\sum_{k}C'_ke^{ik2\pi j/N}\) where \(C'_k =
C_ke^{ikr2\pi/N}\). For \verb|nPatch|~patches we resolve
`wavenumbers' \(|k|<\verb|nPatch|/2\), so set row vector
\(\verb|ks| = k2\pi/N\) for `wavenumbers' \(k = (0,1,
\ldots, k_{\max}, -k_{\max}, \ldots, -1)\) for odd~\(N\),

%}
    iV = 1:nVars;  
%{
\end{matlab}
Now set wavenumbers.
\begin{matlab}
%}
  kMax = floor((nPatch-1)/2); 
  ks = 2*pi/nPatch*(mod((0:nPatch-1)+kMax,nPatch)-kMax); 
%{
\end{matlab}
Test for reality of the field values, and define a function
accordingly.
\begin{matlab}
%}
  if imag(u([2 nSubP-1],:,:))==0, uclean=@(u) real(u);
    else uclean=@(u) u; 
    end
%{
\end{matlab}
Compute the Fourier transform of the patch centre-values for
all the fields. If there are an even number of points, then
zero the zig-zag mode in the \textsc{ft} and add it in later
as cosine.
\begin{matlab}
%}
  Cleft = fft(u(   2   ,:,:));
  Cright= fft(u(nSubP-1,:,:));
  if mod(nPatch,2)==0, error('even number of patches'); end 
%{
\end{matlab}
The inverse Fourier transform gives the edge values via a
shift a fraction~\(r\) to the next macroscale grid point.
Enforce reality when appropriate. 
\begin{matlab}
%}
  u(nSubP,:,iV) = uclean(ifft(bsxfun(@times,Cleft ...
      ,exp(1i*bsxfun(@times,ks,+r)))));
  u(  1  ,:,iV) = uclean(ifft(bsxfun(@times,Cright ...
      ,exp(1i*bsxfun(@times,ks,-r)))));
%{
\end{matlab}
Fin, returning the 2/3D array of field values.  
%}